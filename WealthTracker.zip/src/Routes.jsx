import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import AnalyticsDashboard from './pages/analytics-dashboard';
import MainDashboard from './pages/main-dashboard';
import LandingPage from './pages/landing-page';
import WealthProjectionDetails from './pages/wealth-projection-details';
import DreamSwapCalculator from './pages/dream-swap-calculator';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/analytics-dashboard" element={<AnalyticsDashboard />} />
        <Route path="/main-dashboard" element={<MainDashboard />} />
        <Route path="/landing-page" element={<LandingPage />} />
        <Route path="/wealth-projection-details" element={<WealthProjectionDetails />} />
        <Route path="/dream-swap-calculator" element={<DreamSwapCalculator />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
