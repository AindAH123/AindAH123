import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const Breadcrumbs = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const breadcrumbMap = {
    '/main-dashboard': [
      { label: 'Dashboard', path: '/main-dashboard' }
    ],
    '/wealth-projection-details': [
      { label: 'Dashboard', path: '/main-dashboard' },
      { label: 'Wealth Projections', path: '/wealth-projection-details' }
    ],
    '/dream-swap-calculator': [
      { label: 'Dashboard', path: '/main-dashboard' },
      { label: 'Dream Swap', path: '/dream-swap-calculator' }
    ],
    '/analytics-dashboard': [
      { label: 'Dashboard', path: '/main-dashboard' },
      { label: 'Analytics', path: '/analytics-dashboard' }
    ]
  };

  const currentBreadcrumbs = breadcrumbMap?.[location?.pathname] || [];

  if (currentBreadcrumbs?.length <= 1) {
    return null;
  }

  const handleNavigation = (path) => {
    navigate(path);
  };

  return (
    <div className="breadcrumb-container">
      <nav className="breadcrumb-nav" aria-label="Breadcrumb">
        {currentBreadcrumbs?.map((crumb, index) => {
          const isLast = index === currentBreadcrumbs?.length - 1;
          
          return (
            <div key={crumb?.path} className="breadcrumb-item">
              {index > 0 && (
                <span className="breadcrumb-separator">
                  <Icon name="ChevronRight" size={16} />
                </span>
              )}
              {isLast ? (
                <span className="breadcrumb-link active" aria-current="page">
                  {crumb?.label}
                </span>
              ) : (
                <button
                  onClick={() => handleNavigation(crumb?.path)}
                  className="breadcrumb-link"
                >
                  {crumb?.label}
                </button>
              )}
            </div>
          );
        })}
      </nav>
    </div>
  );
};

export default Breadcrumbs;