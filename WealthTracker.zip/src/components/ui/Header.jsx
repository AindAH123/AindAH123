import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import { getTheme, saveTheme } from '../../utils/globalState';

const Header = () => {
  const location = useLocation();
  const [theme, setTheme] = useState('light');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Load theme from localStorage
    const savedTheme = getTheme();
    setTheme(savedTheme);
    // Apply dark class for Tailwind dark mode
    if (savedTheme === 'dark') {
      document.documentElement?.classList?.add('dark');
    } else {
      document.documentElement?.classList?.remove('dark');
    }

    // Listen for theme updates
    const handleThemeUpdate = (event) => {
      setTheme(event?.detail);
    };

    window.addEventListener('themeUpdated', handleThemeUpdate);

    return () => {
      window.removeEventListener('themeUpdated', handleThemeUpdate);
    };
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    saveTheme(newTheme);
  };

  const navItems = [
    { path: '/main-dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
    { path: '/wealth-projection-details', label: 'Projections', icon: 'TrendingUp' },
    { path: '/analytics-dashboard', label: 'Analytics', icon: 'BarChart3' },
    { path: '/dream-swap-calculator', label: 'Dream Swap', icon: 'Repeat' }
  ];

  const isActive = (path) => location?.pathname === path;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="content-container">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Icon name="DollarSign" size={20} color="white" />
            </div>
            <span className="text-xl font-bold text-foreground">WealthTracker</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-1">
            {navItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  isActive(item?.path)
                    ? 'bg-primary text-white' :'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <Icon name={item?.icon} size={18} />
                <span className="text-sm font-medium">{item?.label}</span>
              </Link>
            ))}
          </nav>

          <div className="flex items-center space-x-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-muted transition-colors"
              aria-label="Toggle theme"
            >
              <Icon
                name={theme === 'light' ? 'Moon' : 'Sun'}
                size={20}
                color="var(--color-foreground)"
              />
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
              aria-label="Toggle menu"
            >
              <Icon
                name={isMobileMenuOpen ? 'X' : 'Menu'}
                size={24}
                color="var(--color-foreground)"
              />
            </button>
          </div>
        </div>

        {isMobileMenuOpen && (
          <nav className="md:hidden py-4 space-y-2 border-t border-border">
            {navItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive(item?.path)
                    ? 'bg-primary text-white' :'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <Icon name={item?.icon} size={20} />
                <span className="font-medium">{item?.label}</span>
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;