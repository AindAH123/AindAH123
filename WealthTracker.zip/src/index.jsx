import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/tailwind.css";
import "./styles/index.css";
import { getTheme } from "./utils/globalState";

// Initialize theme on app load
const savedTheme = getTheme();
document.documentElement?.setAttribute("data-theme", savedTheme);

const root = ReactDOM?.createRoot(document.getElementById("root"));

root.render(<App />);
