import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';

const CategoryBreakdownCard = ({ expenses }) => {
  const categoryData = expenses?.reduce((acc, expense) => {
    const monthlyAmount = expense?.frequency === 'monthly' ? expense?.amount :
                         expense?.frequency === 'weekly' ? expense?.amount * 4.33 :
                         expense?.frequency === 'yearly' ? expense?.amount / 12 :
                         expense?.amount * 365 / 12;
    
    const existing = acc?.find(item => item?.category === expense?.category);
    if (existing) {
      existing.amount += monthlyAmount;
    } else {
      acc?.push({
        category: expense?.category,
        amount: monthlyAmount,
        count: 1
      });
    }
    return acc;
  }, []);

  const sortedData = categoryData?.sort((a, b) => b?.amount - a?.amount);
  const totalSpend = sortedData?.reduce((sum, item) => sum + item?.amount, 0);

  const colors = [
    'var(--color-primary)',
    'var(--color-secondary)',
    'var(--color-accent)',
    '#059669',
    '#D97706',
    '#DC2626'
  ];

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      const percentage = ((payload?.[0]?.value / totalSpend) * 100)?.toFixed(1);
      return (
        <div className="bg-card border border-border rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium text-foreground mb-1">{payload?.[0]?.payload?.category}</p>
          <p className="text-lg font-semibold text-primary data-text">
            ${payload?.[0]?.value?.toFixed(2)}
          </p>
          <p className="text-xs text-muted-foreground">{percentage}% of total</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-1">
            Spending by Category
          </h2>
          <p className="text-sm text-muted-foreground">
            Monthly breakdown of your expenses
          </p>
        </div>
        <div className="p-3 rounded-lg bg-primary/10">
          <Icon name="PieChart" size={24} color="var(--color-primary)" />
        </div>
      </div>
      {sortedData?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="p-4 rounded-full bg-muted mb-4">
            <Icon name="BarChart3" size={32} color="var(--color-muted-foreground)" />
          </div>
          <p className="text-muted-foreground">No expense data available</p>
        </div>
      ) : (
        <>
          <div className="w-full h-64 md:h-80 mb-6" aria-label="Category Spending Bar Chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sortedData} margin={{ top: 10, right: 10, left: 10, bottom: 40 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="category" 
                  angle={-45}
                  textAnchor="end"
                  height={80}
                  tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                />
                <YAxis 
                  tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                  tickFormatter={(value) => `$${value?.toFixed(0)}`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="amount" radius={[8, 8, 0, 0]}>
                  {sortedData?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={colors?.[index % colors?.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3">
            {sortedData?.map((item, index) => {
              const percentage = ((item?.amount / totalSpend) * 100)?.toFixed(1);
              return (
                <div key={item?.category} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center space-x-3 flex-1 min-w-0">
                    <div 
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: colors?.[index % colors?.length] }}
                    />
                    <span className="text-sm font-medium text-foreground truncate">
                      {item?.category}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 flex-shrink-0">
                    <span className="text-sm text-muted-foreground caption">
                      {percentage}%
                    </span>
                    <span className="text-sm font-semibold text-foreground data-text min-w-[5rem] text-right">
                      ${item?.amount?.toFixed(2)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};

export default CategoryBreakdownCard;