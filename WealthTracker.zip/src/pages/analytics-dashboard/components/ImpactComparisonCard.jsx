import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

import { Checkbox } from '../../../components/ui/Checkbox';

const ImpactComparisonCard = ({ expenses }) => {
  const [selectedExpenses, setSelectedExpenses] = useState([]);

  const expensesWithMonthly = expenses?.map(expense => {
    const monthlyAmount = expense?.frequency === 'monthly' ? expense?.amount :
                         expense?.frequency === 'weekly' ? expense?.amount * 4.33 :
                         expense?.frequency === 'yearly' ? expense?.amount / 12 :
                         expense?.amount * 365 / 12;
    return { ...expense, monthlyAmount };
  });

  const sortedExpenses = expensesWithMonthly?.sort((a, b) => b?.monthlyAmount - a?.monthlyAmount);

  const handleToggleExpense = (expenseId) => {
    setSelectedExpenses(prev => 
      prev?.includes(expenseId) 
        ? prev?.filter(id => id !== expenseId)
        : [...prev, expenseId]
    );
  };

  const calculateImpact = () => {
    const monthlySavings = selectedExpenses?.reduce((sum, id) => {
      const expense = expensesWithMonthly?.find(e => e?.id === id);
      return sum + (expense?.monthlyAmount || 0);
    }, 0);

    const annualSavings = monthlySavings * 12;
    const fiveYearWealth = monthlySavings * 12 * 5 * 1.07;
    const tenYearWealth = monthlySavings * 12 * 10 * 1.07;

    return { monthlySavings, annualSavings, fiveYearWealth, tenYearWealth };
  };

  const impact = calculateImpact();

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-1">
            Monthly Cut Impact
          </h2>
          <p className="text-sm text-muted-foreground">
            Select expenses to see potential savings
          </p>
        </div>
        <div className="p-3 rounded-lg bg-success/10">
          <Icon name="Calculator" size={24} color="var(--color-success)" />
        </div>
      </div>
      {sortedExpenses?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="p-4 rounded-full bg-muted mb-4">
            <Icon name="Scissors" size={32} color="var(--color-muted-foreground)" />
          </div>
          <p className="text-muted-foreground">Add expenses to see impact analysis</p>
        </div>
      ) : (
        <>
          <div className="space-y-2 mb-6 max-h-64 overflow-y-auto">
            {sortedExpenses?.map(expense => (
              <label 
                key={expense?.id}
                className="flex items-center justify-between p-3 rounded-lg border border-border cursor-pointer hover:bg-muted/50 transition-all duration-250"
              >
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  <Checkbox
                    checked={selectedExpenses?.includes(expense?.id)}
                    onChange={() => handleToggleExpense(expense?.id)}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {expense?.name}
                    </p>
                    <p className="text-xs text-muted-foreground caption">
                      {expense?.category}
                    </p>
                  </div>
                </div>
                <span className="text-sm font-semibold text-foreground data-text ml-4 whitespace-nowrap">
                  ${expense?.monthlyAmount?.toFixed(2)}
                </span>
              </label>
            ))}
          </div>

          {selectedExpenses?.length > 0 && (
            <div className="space-y-4 p-4 md:p-6 rounded-lg bg-gradient-to-br from-success/10 to-primary/10 border border-success/20">
              <div className="flex items-center justify-between pb-4 border-b border-border">
                <span className="text-sm text-muted-foreground">Monthly Savings</span>
                <span className="text-xl md:text-2xl font-bold text-success data-text">
                  ${impact?.monthlySavings?.toFixed(2)}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 rounded-lg bg-card/50">
                  <p className="text-xs text-muted-foreground caption mb-1">Annual Savings</p>
                  <p className="text-lg md:text-xl font-semibold text-foreground data-text">
                    ${impact?.annualSavings?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>

                <div className="text-center p-3 rounded-lg bg-card/50">
                  <p className="text-xs text-muted-foreground caption mb-1">5-Year Wealth</p>
                  <p className="text-lg md:text-xl font-semibold text-primary data-text">
                    ${impact?.fiveYearWealth?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>

                <div className="text-center p-3 rounded-lg bg-card/50">
                  <p className="text-xs text-muted-foreground caption mb-1">10-Year Wealth</p>
                  <p className="text-lg md:text-xl font-semibold text-primary data-text">
                    ${impact?.tenYearWealth?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
              </div>

              <p className="text-xs text-center text-muted-foreground caption">
                Assuming 7% annual investment return
              </p>
            </div>
          )}

          {selectedExpenses?.length === 0 && (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">
                Select expenses above to calculate potential savings
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ImpactComparisonCard;