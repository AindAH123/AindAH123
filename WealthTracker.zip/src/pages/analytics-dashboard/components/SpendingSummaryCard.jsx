import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SpendingSummaryCard = ({ expenses }) => {
  const [copied, setCopied] = useState(false);

  const calculateTotals = () => {
    const monthlyTotal = expenses?.reduce((sum, expense) => {
      const monthlyAmount = expense?.frequency === 'monthly' ? expense?.amount :
                           expense?.frequency === 'weekly' ? expense?.amount * 4.33 :
                           expense?.frequency === 'yearly' ? expense?.amount / 12 :
                           expense?.amount * 365 / 12;
      return sum + monthlyAmount;
    }, 0);

    const annualTotal = monthlyTotal * 12;
    const thirtyYearLost = monthlyTotal * 12 * 30 * 1.07;

    return { monthlyTotal, annualTotal, thirtyYearLost };
  };

  const getCategoryBreakdown = () => {
    const breakdown = expenses?.reduce((acc, expense) => {
      const monthlyAmount = expense?.frequency === 'monthly' ? expense?.amount :
                           expense?.frequency === 'weekly' ? expense?.amount * 4.33 :
                           expense?.frequency === 'yearly' ? expense?.amount / 12 :
                           expense?.amount * 365 / 12;
      
      if (!acc?.[expense?.category]) {
        acc[expense.category] = 0;
      }
      acc[expense.category] += monthlyAmount;
      return acc;
    }, {});

    return Object.entries(breakdown)?.sort(([, a], [, b]) => b - a)?.map(([category, amount]) => ({ category, amount }));
  };

  const handleCopySummary = () => {
    const totals = calculateTotals();
    const categoryBreakdown = getCategoryBreakdown();
    
    const summary = `The Guillotine - Spending Analysis Summary
Generated: ${new Date()?.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}

OVERVIEW
--------
Total Monthly Spending: $${totals?.monthlyTotal?.toFixed(2)}
Total Annual Spending: $${totals?.annualTotal?.toFixed(2)}
30-Year Wealth Lost: $${totals?.thirtyYearLost?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}

CATEGORY BREAKDOWN
------------------
${categoryBreakdown?.map(item => `${item?.category}: $${item?.amount?.toFixed(2)}/month`)?.join('\n')}

TOP EXPENSES
------------
${expenses?.map(e => ({
    ...e,
    monthlyAmount: e?.frequency === 'monthly' ? e?.amount :
                   e?.frequency === 'weekly' ? e?.amount * 4.33 :
                   e?.frequency === 'yearly' ? e?.amount / 12 :
                   e?.amount * 365 / 12
  }))?.sort((a, b) => b?.monthlyAmount - a?.monthlyAmount)?.slice(0, 5)?.map((e, i) => `${i + 1}. ${e?.name} - $${e?.monthlyAmount?.toFixed(2)}/month`)?.join('\n')}

Note: Wealth calculations assume 7% annual investment return.`;

    navigator.clipboard?.writeText(summary)?.then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const totals = calculateTotals();
  const categoryBreakdown = getCategoryBreakdown();

  return (
    <div className="card">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-1">
            Spending Summary
          </h2>
          <p className="text-sm text-muted-foreground">
            Complete overview of your financial habits
          </p>
        </div>
        <Button
          variant="outline"
          iconName={copied ? "Check" : "Copy"}
          iconPosition="left"
          onClick={handleCopySummary}
          disabled={expenses?.length === 0}
        >
          {copied ? 'Copied!' : 'Copy Summary'}
        </Button>
      </div>
      {expenses?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="p-4 rounded-full bg-muted mb-4">
            <Icon name="FileText" size={32} color="var(--color-muted-foreground)" />
          </div>
          <p className="text-muted-foreground">No data available for summary</p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 md:p-6 rounded-lg bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="Calendar" size={18} color="var(--color-primary)" />
                <p className="text-xs text-muted-foreground caption">Monthly Total</p>
              </div>
              <p className="text-2xl md:text-3xl font-bold text-primary data-text">
                ${totals?.monthlyTotal?.toFixed(2)}
              </p>
            </div>

            <div className="p-4 md:p-6 rounded-lg bg-gradient-to-br from-accent/10 to-warning/10 border border-accent/20">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="CalendarDays" size={18} color="var(--color-accent)" />
                <p className="text-xs text-muted-foreground caption">Annual Total</p>
              </div>
              <p className="text-2xl md:text-3xl font-bold text-accent data-text">
                ${totals?.annualTotal?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>

            <div className="p-4 md:p-6 rounded-lg bg-gradient-to-br from-destructive/10 to-error/10 border border-destructive/20">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="TrendingDown" size={18} color="var(--color-destructive)" />
                <p className="text-xs text-muted-foreground caption">30-Year Lost</p>
              </div>
              <p className="text-2xl md:text-3xl font-bold text-destructive data-text">
                ${totals?.thirtyYearLost?.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </p>
            </div>
          </div>

          <div className="p-4 md:p-6 rounded-lg bg-muted/50">
            <h3 className="text-base md:text-lg font-semibold text-foreground mb-4">
              Category Distribution
            </h3>
            <div className="space-y-3">
              {categoryBreakdown?.map(item => {
                const percentage = ((item?.amount / totals?.monthlyTotal) * 100)?.toFixed(1);
                return (
                  <div key={item?.category}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-foreground">{item?.category}</span>
                      <span className="text-sm font-semibold text-foreground data-text">
                        ${item?.amount?.toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-border rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary rounded-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground caption mt-1">
                      {percentage}% of monthly spending
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-4 rounded-lg bg-accent/10 border border-accent/20">
            <div className="flex items-start space-x-3">
              <Icon name="Lightbulb" size={20} color="var(--color-accent)" className="flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground mb-1">
                  Optimization Insight
                </p>
                <p className="text-sm text-muted-foreground">
                  Your top 3 categories account for {
                    categoryBreakdown?.slice(0, 3)?.reduce((sum, item) => 
                      sum + ((item?.amount / totals?.monthlyTotal) * 100), 0
                    )?.toFixed(1)
                  }% of your monthly spending. Focus on these areas for maximum impact.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SpendingSummaryCard;