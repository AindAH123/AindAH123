import React from 'react';
import Icon from '../../../components/AppIcon';

const TopExpensesCard = ({ expenses }) => {
  const expensesWithMonthly = expenses?.map(expense => {
    const monthlyAmount = expense?.frequency === 'monthly' ? expense?.amount :
                         expense?.frequency === 'weekly' ? expense?.amount * 4.33 :
                         expense?.frequency === 'yearly' ? expense?.amount / 12 :
                         expense?.amount * 365 / 12;
    return { ...expense, monthlyAmount };
  });

  const topExpenses = expensesWithMonthly?.sort((a, b) => b?.monthlyAmount - a?.monthlyAmount)?.slice(0, 5);

  const getFrequencyLabel = (frequency) => {
    const labels = {
      daily: 'per day',
      weekly: 'per week',
      monthly: 'per month',
      yearly: 'per year'
    };
    return labels?.[frequency] || 'per month';
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Entertainment': 'Tv',
      'Food & Dining': 'UtensilsCrossed',
      'Shopping': 'ShoppingBag',
      'Transportation': 'Car',
      'Health & Fitness': 'Heart',
      'Utilities': 'Zap',
      'Other': 'MoreHorizontal'
    };
    return icons?.[category] || 'DollarSign';
  };

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-1">
            Top 5 Biggest Expenses
          </h2>
          <p className="text-sm text-muted-foreground">
            Your highest-impact spending items
          </p>
        </div>
        <div className="p-3 rounded-lg bg-destructive/10">
          <Icon name="TrendingUp" size={24} color="var(--color-destructive)" />
        </div>
      </div>
      {topExpenses?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="p-4 rounded-full bg-muted mb-4">
            <Icon name="Receipt" size={32} color="var(--color-muted-foreground)" />
          </div>
          <p className="text-muted-foreground">No expenses to display</p>
        </div>
      ) : (
        <div className="space-y-3">
          {topExpenses?.map((expense, index) => (
            <div 
              key={expense?.id}
              className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/50 transition-all duration-250"
            >
              <div className="flex items-center space-x-4 flex-1 min-w-0">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 flex-shrink-0">
                  <span className="text-lg font-bold text-primary data-text">
                    {index + 1}
                  </span>
                </div>
                <div className="p-2 rounded-lg bg-muted flex-shrink-0">
                  <Icon name={getCategoryIcon(expense?.category)} size={20} color="var(--color-foreground)" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm md:text-base font-medium text-foreground truncate mb-1">
                    {expense?.name}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <span className="caption">{expense?.category}</span>
                    <span>•</span>
                    <span className="caption">{expense?.type}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end space-y-1 flex-shrink-0 ml-4">
                <span className="text-base md:text-lg font-semibold text-foreground data-text whitespace-nowrap">
                  ${expense?.monthlyAmount?.toFixed(2)}
                </span>
                <span className="text-xs text-muted-foreground caption whitespace-nowrap">
                  ${expense?.amount?.toFixed(2)} {getFrequencyLabel(expense?.frequency)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TopExpensesCard;