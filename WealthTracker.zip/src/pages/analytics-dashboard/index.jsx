import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumbs from '../../components/ui/Breadcrumbs';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import CategoryBreakdownCard from './components/CategoryBreakdownCard';
import TopExpensesCard from './components/TopExpensesCard';
import ImpactComparisonCard from './components/ImpactComparisonCard';
import SpendingSummaryCard from './components/SpendingSummaryCard';
import { getExpenses } from '../../utils/globalState';

const AnalyticsDashboard = () => {
  const navigate = useNavigate();
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    // Load expenses from localStorage
    const savedExpenses = getExpenses();
    setExpenses(savedExpenses);

    // Listen for expense updates
    const handleExpensesUpdate = (event) => {
      setExpenses(event?.detail);
    };

    window.addEventListener('expensesUpdated', handleExpensesUpdate);

    return () => {
      window.removeEventListener('expensesUpdated', handleExpensesUpdate);
    };
  }, []);

  const calculateTotalMonthly = () => {
    return expenses?.reduce((sum, expense) => {
      const monthlyAmount = expense?.frequency === 'monthly' ? expense?.amount :
                           expense?.frequency === 'weekly' ? expense?.amount * 4.33 :
                           expense?.frequency === 'yearly' ? expense?.amount / 12 :
                           expense?.amount * 365 / 12;
      return sum + monthlyAmount;
    }, 0);
  };

  const totalMonthly = calculateTotalMonthly();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="main-content">
        <div className="content-container">
          <Breadcrumbs />

          <div className="mb-8 animate-in">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-4">
              <div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-2">
                  Analytics Dashboard
                </h1>
                <p className="text-base md:text-lg text-muted-foreground">
                  Comprehensive insights into your spending patterns and optimization opportunities
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="ArrowLeft"
                  iconPosition="left"
                  onClick={() => navigate('/main-dashboard')}
                >
                  Dashboard
                </Button>
                <Button
                  variant="default"
                  iconName="Repeat"
                  iconPosition="left"
                  onClick={() => navigate('/dream-swap-calculator')}
                >
                  Dream Swap
                </Button>
              </div>
            </div>

            {expenses?.length > 0 && (
              <div className="p-4 md:p-6 rounded-2xl bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 border border-primary/20">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 rounded-lg bg-card">
                      <Icon name="DollarSign" size={28} color="var(--color-primary)" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground caption mb-1">
                        Total Monthly Spending
                      </p>
                      <p className="text-3xl md:text-4xl font-bold text-primary data-text">
                        ${totalMonthly?.toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col md:items-end space-y-1">
                    <p className="text-sm text-muted-foreground caption">
                      Tracking {expenses?.length} expense{expenses?.length !== 1 ? 's' : ''}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Last updated: {new Date()?.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {expenses?.length === 0 ? (
            <div className="card text-center py-16 animate-in stagger-1">
              <div className="max-w-md mx-auto">
                <div className="p-6 rounded-full bg-muted inline-block mb-6">
                  <Icon name="BarChart3" size={48} color="var(--color-muted-foreground)" />
                </div>
                <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-3">
                  No Analytics Available
                </h2>
                <p className="text-base text-muted-foreground mb-8">
                  Start tracking your expenses to unlock powerful spending insights and optimization recommendations.
                </p>
                <Button
                  variant="default"
                  size="lg"
                  iconName="Plus"
                  iconPosition="left"
                  onClick={() => navigate('/main-dashboard')}
                >
                  Add Your First Expense
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6 md:space-y-8">
              <div className="animate-in stagger-1">
                <SpendingSummaryCard expenses={expenses} />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                <div className="animate-in stagger-2">
                  <CategoryBreakdownCard expenses={expenses} />
                </div>
                <div className="animate-in stagger-2">
                  <TopExpensesCard expenses={expenses} />
                </div>
              </div>

              <div className="animate-in stagger-3">
                <ImpactComparisonCard expenses={expenses} />
              </div>

              <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-br from-primary/5 to-accent/5 border border-border animate-in stagger-3">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 rounded-lg bg-primary/10 flex-shrink-0">
                      <Icon name="Target" size={28} color="var(--color-primary)" />
                    </div>
                    <div>
                      <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-2">
                        Ready to Take Action?
                      </h3>
                      <p className="text-sm md:text-base text-muted-foreground">
                        Use the Dream Swap calculator to see how cutting specific expenses can help you reach your financial goals faster.
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="default"
                    size="lg"
                    iconName="Repeat"
                    iconPosition="right"
                    onClick={() => navigate('/dream-swap-calculator')}
                    className="flex-shrink-0"
                  >
                    Try Dream Swap
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AnalyticsDashboard;