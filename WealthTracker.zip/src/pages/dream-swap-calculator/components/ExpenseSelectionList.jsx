import React from 'react';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const ExpenseSelectionList = ({ expenses, selectedExpenses, onExpenseToggle, monthlyFreedCash }) => {
  const subscriptions = expenses?.filter(exp => exp?.type === 'subscription');
  const habits = expenses?.filter(exp => exp?.type === 'habit');

  const renderExpenseItem = (expense) => {
    const isSelected = selectedExpenses?.includes(expense?.id);
    const monthlyAmount = calculateMonthlyAmount(expense?.amount, expense?.frequency);

    return (
      <div
        key={expense?.id}
        className={`p-4 rounded-xl border transition-all duration-250 ${
          isSelected
            ? 'border-primary bg-primary/5' :'border-border hover:border-primary/30 hover:bg-muted/50'
        }`}
      >
        <Checkbox
          checked={isSelected}
          onChange={() => onExpenseToggle(expense?.id)}
          label={
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center space-x-3 min-w-0 flex-1">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isSelected ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                }`}>
                  <Icon name={getCategoryIcon(expense?.category)} size={20} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-foreground text-truncate">{expense?.name}</p>
                  <p className="text-xs text-muted-foreground capitalize">
                    {expense?.category} • {expense?.frequency}
                  </p>
                </div>
              </div>
              <div className="text-right ml-4 flex-shrink-0">
                <p className="font-semibold text-foreground data-text whitespace-nowrap">
                  ${monthlyAmount?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground">/month</p>
              </div>
            </div>
          }
        />
      </div>
    );
  };

  return (
    <div className="card animate-in stagger-1">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center">
            <Icon name="ListChecks" size={24} className="text-secondary" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold text-foreground">Select Expenses to Cut</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Choose which expenses you're willing to eliminate
            </p>
          </div>
        </div>
        {selectedExpenses?.length > 0 && (
          <div className="hidden md:block px-4 py-2 rounded-lg bg-success/10 border border-success/20">
            <p className="text-sm font-medium text-success">
              {selectedExpenses?.length} selected
            </p>
          </div>
        )}
      </div>
      {monthlyFreedCash > 0 && (
        <div className="mb-6 p-4 md:p-6 rounded-xl bg-success/10 border border-success/20">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 md:w-12 md:h-12 rounded-lg bg-success flex items-center justify-center flex-shrink-0">
                <Icon name="TrendingUp" size={20} className="text-white md:w-6 md:h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Monthly Cash Freed</p>
                <p className="text-2xl md:text-3xl font-bold text-success data-text">
                  ${monthlyFreedCash?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Annual Impact</p>
              <p className="text-lg md:text-xl font-semibold text-foreground data-text">
                ${(monthlyFreedCash * 12)?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
      )}
      <div className="space-y-6">
        {subscriptions?.length > 0 && (
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <Icon name="CreditCard" size={18} className="text-muted-foreground" />
              <h3 className="text-lg font-semibold text-foreground">Subscriptions</h3>
              <span className="text-sm text-muted-foreground">({subscriptions?.length})</span>
            </div>
            <div className="space-y-3">
              {subscriptions?.map(renderExpenseItem)}
            </div>
          </div>
        )}

        {habits?.length > 0 && (
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <Icon name="Coffee" size={18} className="text-muted-foreground" />
              <h3 className="text-lg font-semibold text-foreground">Habits</h3>
              <span className="text-sm text-muted-foreground">({habits?.length})</span>
            </div>
            <div className="space-y-3">
              {habits?.map(renderExpenseItem)}
            </div>
          </div>
        )}
      </div>
      {expenses?.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <Icon name="Inbox" size={32} className="text-muted-foreground md:w-10 md:h-10" />
          </div>
          <p className="text-foreground font-medium mb-2">No Expenses Yet</p>
          <p className="text-sm text-muted-foreground">
            Add expenses in the dashboard to start planning your goal
          </p>
        </div>
      )}
    </div>
  );
};

const calculateMonthlyAmount = (amount, frequency) => {
  const conversions = {
    daily: 30,
    weekly: 4.33,
    monthly: 1,
    yearly: 1 / 12
  };
  return amount * (conversions?.[frequency] || 1);
};

const getCategoryIcon = (category) => {
  const icons = {
    entertainment: 'Tv',
    food: 'UtensilsCrossed',
    transportation: 'Car',
    shopping: 'ShoppingBag',
    health: 'Heart',
    education: 'GraduationCap',
    utilities: 'Zap',
    other: 'MoreHorizontal'
  };
  return icons?.[category] || 'DollarSign';
};

export default ExpenseSelectionList;