import React from 'react';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';

const GoalInputForm = ({ goalName, targetAmount, onGoalNameChange, onTargetAmountChange, error }) => {
  return (
    <div className="card animate-in">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <Icon name="Target" size={24} className="text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Set Your Financial Goal</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Define what you're saving for and how much you need
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <Input
          label="Dream Name"
          type="text"
          placeholder="e.g., European Vacation, New Car, Emergency Fund"
          value={goalName}
          onChange={(e) => onGoalNameChange(e?.target?.value)}
          required
          description="Give your goal a memorable name"
          className="w-full"
        />

        <Input
          label="Target Amount"
          type="number"
          placeholder="10000"
          value={targetAmount}
          onChange={(e) => onTargetAmountChange(e?.target?.value)}
          required
          min="1"
          description="How much money do you need?"
          error={error}
          className="w-full"
        />
      </div>
      {goalName && targetAmount && !error && (
        <div className="mt-6 p-4 rounded-xl bg-accent/10 border border-accent/20">
          <div className="flex items-start space-x-3">
            <Icon name="Lightbulb" size={20} className="text-accent mt-0.5 flex-shrink-0" />
            <p className="text-sm text-foreground">
              <span className="font-medium">Your Goal:</span> Save{' '}
              <span className="font-semibold data-text">${parseFloat(targetAmount)?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>{' '}
              for <span className="font-semibold">{goalName}</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GoalInputForm;