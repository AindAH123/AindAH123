import React from 'react';
import Icon from '../../../components/AppIcon';

const GoalTimelineDisplay = ({ monthsToGoal, targetAmount, monthlyFreedCash, annualReturn }) => {
  const years = Math.floor(monthsToGoal / 12);
  const months = Math.round(monthsToGoal % 12);

  const formatTimeToGoal = () => {
    if (monthsToGoal === Infinity) {
      return 'Goal Not Achievable';
    }
    if (years === 0) {
      return `${months} ${months === 1 ? 'Month' : 'Months'}`;
    }
    if (months === 0) {
      return `${years} ${years === 1 ? 'Year' : 'Years'}`;
    }
    return `${years} ${years === 1 ? 'Year' : 'Years'}, ${months} ${months === 1 ? 'Month' : 'Months'}`;
  };

  const getStatusColor = () => {
    if (monthsToGoal === Infinity) return 'error';
    if (monthsToGoal <= 12) return 'success';
    if (monthsToGoal <= 36) return 'warning';
    return 'primary';
  };

  const statusColor = getStatusColor();

  return (
    <div className="card animate-in stagger-2">
      <div className="text-center">
        <div className="flex items-center justify-center space-x-3 mb-6">
          <div className={`w-12 h-12 md:w-16 md:h-16 rounded-xl bg-${statusColor}/10 flex items-center justify-center`}>
            <Icon 
              name={monthsToGoal === Infinity ? 'AlertCircle' : 'Calendar'} 
              size={24} 
              className={`text-${statusColor} md:w-8 md:h-8`} 
            />
          </div>
          <div className="text-left">
            <p className="text-sm text-muted-foreground">Time to Goal</p>
            <h2 className={`text-2xl md:text-3xl font-bold text-${statusColor}`}>
              {formatTimeToGoal()}
            </h2>
          </div>
        </div>

        {monthsToGoal !== Infinity ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mt-6">
            <div className="p-4 rounded-xl bg-muted/50">
              <p className="text-xs text-muted-foreground mb-1">Target Amount</p>
              <p className="text-lg md:text-xl font-semibold text-foreground data-text">
                ${parseFloat(targetAmount)?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-muted/50">
              <p className="text-xs text-muted-foreground mb-1">Monthly Savings</p>
              <p className="text-lg md:text-xl font-semibold text-foreground data-text">
                ${monthlyFreedCash?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-muted/50">
              <p className="text-xs text-muted-foreground mb-1">Annual Return</p>
              <p className="text-lg md:text-xl font-semibold text-foreground data-text">
                {annualReturn?.toFixed(1)}%
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-6 p-4 md:p-6 rounded-xl bg-error/10 border border-error/20">
            <div className="flex items-start space-x-3">
              <Icon name="AlertTriangle" size={20} className="text-error mt-0.5 flex-shrink-0" />
              <div className="text-left">
                <p className="font-medium text-error mb-2">Cannot Achieve Goal</p>
                <p className="text-sm text-muted-foreground">
                  With 0% annual return, you need to select expenses totaling at least{' '}
                  <span className="font-semibold data-text">
                    ${(parseFloat(targetAmount) / 360)?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}/month
                  </span>{' '}
                  to reach your goal in 30 years. Consider adjusting your investment settings or selecting more expenses.
                </p>
              </div>
            </div>
          </div>
        )}

        {monthsToGoal !== Infinity && monthsToGoal <= 12 && (
          <div className="mt-6 p-4 rounded-xl bg-success/10 border border-success/20">
            <div className="flex items-start space-x-3">
              <Icon name="PartyPopper" size={20} className="text-success mt-0.5 flex-shrink-0" />
              <p className="text-sm text-foreground text-left">
                <span className="font-medium">Excellent progress!</span> You could reach your goal within a year by cutting these expenses.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GoalTimelineDisplay;