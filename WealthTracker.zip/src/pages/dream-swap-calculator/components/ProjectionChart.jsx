import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Icon from '../../../components/AppIcon';

const ProjectionChart = ({ chartData, targetAmount, monthsToGoal }) => {
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg shadow-lg p-4">
          <p className="text-sm font-medium text-foreground mb-2">
            Month {payload?.[0]?.payload?.month}
          </p>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">
              Accumulated:{' '}
              <span className="font-semibold text-primary data-text">
                ${payload?.[0]?.value?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="card animate-in stagger-3">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
          <Icon name="TrendingUp" size={24} className="text-accent" />
        </div>
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Goal Achievement Timeline</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Watch your savings grow with compound interest
          </p>
        </div>
      </div>
      {chartData?.length > 0 ? (
        <>
          <div className="w-full h-64 md:h-80 lg:h-96" aria-label="Goal Achievement Projection Chart">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis
                  dataKey="month"
                  stroke="var(--color-muted-foreground)"
                  tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                  label={{ value: 'Months', position: 'insideBottom', offset: -5, fill: 'var(--color-muted-foreground)' }}
                />
                <YAxis
                  stroke="var(--color-muted-foreground)"
                  tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                  tickFormatter={(value) => `$${(value / 1000)?.toFixed(0)}k`}
                  label={{ value: 'Amount ($)', angle: -90, position: 'insideLeft', fill: 'var(--color-muted-foreground)' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  wrapperStyle={{ paddingTop: '20px' }}
                  iconType="line"
                  formatter={(value) => <span style={{ color: 'var(--color-foreground)', fontSize: '14px' }}>{value}</span>}
                />
                <Line
                  type="monotone"
                  dataKey="accumulated"
                  stroke="var(--color-primary)"
                  strokeWidth={3}
                  dot={false}
                  name="Accumulated Savings"
                  activeDot={{ r: 6, fill: 'var(--color-primary)' }}
                />
                {monthsToGoal !== Infinity && (
                  <Line
                    type="monotone"
                    dataKey="target"
                    stroke="var(--color-success)"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                    name="Target Amount"
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 rounded-full bg-primary flex-shrink-0"></div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-muted-foreground">Accumulated Savings</p>
                  <p className="text-base font-medium text-foreground">
                    Your money growing with compound interest over time
                  </p>
                </div>
              </div>
            </div>

            {monthsToGoal !== Infinity && (
              <div className="p-4 rounded-xl bg-success/5 border border-success/20">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 rounded-full bg-success flex-shrink-0"></div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-muted-foreground">Target Amount</p>
                    <p className="text-base font-medium text-foreground">
                      Your goal of ${parseFloat(targetAmount)?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="text-center py-12">
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <Icon name="LineChart" size={32} className="text-muted-foreground md:w-10 md:h-10" />
          </div>
          <p className="text-foreground font-medium mb-2">No Data to Display</p>
          <p className="text-sm text-muted-foreground">
            Set a goal and select expenses to see your projection
          </p>
        </div>
      )}
    </div>
  );
};

export default ProjectionChart;