import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Breadcrumbs from '../../components/ui/Breadcrumbs';
import GoalInputForm from './components/GoalInputForm';
import ExpenseSelectionList from './components/ExpenseSelectionList';
import GoalTimelineDisplay from './components/GoalTimelineDisplay';
import ProjectionChart from './components/ProjectionChart';
import Icon from '../../components/AppIcon';
import { getExpenses, getSettings } from '../../utils/globalState';

const DreamSwapCalculator = () => {
  const [goalName, setGoalName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [selectedExpenses, setSelectedExpenses] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [annualReturn, setAnnualReturn] = useState(7);
  const [error, setError] = useState('');

  useEffect(() => {
    // Load expenses from localStorage
    const savedExpenses = getExpenses();
    setExpenses(savedExpenses);

    // Load settings from localStorage
    const savedSettings = getSettings();
    setAnnualReturn(savedSettings?.annualReturn || 7);

    // Listen for expense and settings updates
    const handleExpensesUpdate = (event) => {
      setExpenses(event?.detail);
    };

    const handleSettingsUpdate = (event) => {
      setAnnualReturn(event?.detail?.annualReturn || 7);
    };

    window.addEventListener('expensesUpdated', handleExpensesUpdate);
    window.addEventListener('settingsUpdated', handleSettingsUpdate);

    return () => {
      window.removeEventListener('expensesUpdated', handleExpensesUpdate);
      window.removeEventListener('settingsUpdated', handleSettingsUpdate);
    };
  }, []);

  const calculateMonthlyAmount = (amount, frequency) => {
    const conversions = {
      daily: 30,
      weekly: 4.33,
      monthly: 1,
      yearly: 1 / 12
    };
    return amount * (conversions?.[frequency] || 1);
  };

  const monthlyFreedCash = selectedExpenses?.reduce((total, expenseId) => {
    const expense = expenses?.find(exp => exp?.id === expenseId);
    if (expense) {
      return total + calculateMonthlyAmount(expense?.amount, expense?.frequency);
    }
    return total;
  }, 0);

  const calculateMonthsToGoal = () => {
    if (!targetAmount || parseFloat(targetAmount) <= 0 || monthlyFreedCash <= 0) {
      return Infinity;
    }

    const target = parseFloat(targetAmount);
    const monthlyRate = annualReturn / 100 / 12;

    if (monthlyRate === 0) {
      let months = target / monthlyFreedCash;
      return months > 360 ? Infinity : months;
    }

    let months = 0;
    let accumulated = 0;

    while (accumulated < target && months < 360) {
      accumulated = accumulated * (1 + monthlyRate) + monthlyFreedCash;
      months++;
    }

    return accumulated >= target ? months : Infinity;
  };

  const monthsToGoal = calculateMonthsToGoal();

  const generateChartData = () => {
    if (!targetAmount || parseFloat(targetAmount) <= 0 || monthlyFreedCash <= 0) {
      return [];
    }

    const target = parseFloat(targetAmount);
    const monthlyRate = annualReturn / 100 / 12;
    const maxMonths = Math.min(monthsToGoal === Infinity ? 360 : Math.ceil(monthsToGoal) + 12, 360);
    const data = [];

    let accumulated = 0;

    for (let month = 0; month <= maxMonths; month++) {
      if (month > 0) {
        accumulated = accumulated * (1 + monthlyRate) + monthlyFreedCash;
      }

      data?.push({
        month,
        accumulated: parseFloat(accumulated?.toFixed(2)),
        target: target
      });
    }

    return data;
  };

  const chartData = generateChartData();

  const handleExpenseToggle = (expenseId) => {
    setSelectedExpenses(prev =>
      prev?.includes(expenseId)
        ? prev?.filter(id => id !== expenseId)
        : [...prev, expenseId]
    );
  };

  const handleTargetAmountChange = (value) => {
    setTargetAmount(value);
    if (value && parseFloat(value) <= 0) {
      setError('Target amount must be greater than zero');
    } else {
      setError('');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="main-content">
        <div className="content-container">
          <Breadcrumbs />

          <div className="mb-6 md:mb-8">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-3">
              Dream Swap Calculator
            </h1>
            <p className="text-base md:text-lg text-muted-foreground max-w-3xl">
              Set a financial goal and discover how cutting specific expenses can help you achieve it faster through the power of compound interest.
            </p>
          </div>

          <div className="space-y-6 md:space-y-8">
            <GoalInputForm
              goalName={goalName}
              targetAmount={targetAmount}
              onGoalNameChange={setGoalName}
              onTargetAmountChange={handleTargetAmountChange}
              error={error}
            />

            <ExpenseSelectionList
              expenses={expenses}
              selectedExpenses={selectedExpenses}
              onExpenseToggle={handleExpenseToggle}
              monthlyFreedCash={monthlyFreedCash}
            />

            {goalName && targetAmount && !error && selectedExpenses?.length > 0 && (
              <>
                <GoalTimelineDisplay
                  monthsToGoal={monthsToGoal}
                  targetAmount={targetAmount}
                  monthlyFreedCash={monthlyFreedCash}
                  annualReturn={annualReturn}
                />

                <ProjectionChart
                  chartData={chartData}
                  targetAmount={targetAmount}
                  monthsToGoal={monthsToGoal}
                />
              </>
            )}

            {goalName && targetAmount && !error && selectedExpenses?.length === 0 && (
              <div className="card text-center py-12">
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-warning/10 mx-auto mb-4 flex items-center justify-center">
                  <Icon name="AlertCircle" size={32} className="text-warning md:w-10 md:h-10" />
                </div>
                <p className="text-foreground font-medium mb-2">Select Expenses to Continue</p>
                <p className="text-sm text-muted-foreground">
                  Choose which expenses you're willing to cut to see your goal timeline
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default DreamSwapCalculator;