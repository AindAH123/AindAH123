import React from 'react';
import Icon from '../../../components/AppIcon';

const CTASection = ({ onGetStarted }) => {
  return (
    <section className="py-16 md:py-24 lg:py-32 bg-gradient-to-br from-primary via-primary to-secondary relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(255,255,255,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_30%,rgba(255,255,255,0.08),transparent_50%)]" />
      
      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-in space-y-6 md:space-y-8">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-primary-foreground leading-tight">
            Ready to Take Control of Your Financial Future?
          </h2>
          
          <p className="text-base md:text-lg lg:text-xl text-primary-foreground/90 max-w-2xl mx-auto leading-relaxed">
            Start tracking your expenses today and discover how small changes can lead to significant wealth accumulation over time.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 md:pt-6">
            <button
              onClick={onGetStarted}
              className="group w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-4 rounded-xl bg-primary-foreground text-primary font-medium text-base shadow-lg hover:shadow-xl transition-all duration-250 hover:-translate-y-0.5 touch-target"
            >
              <span>Start Your Journey</span>
              <Icon 
                name="ArrowRight" 
                size={20} 
                className="transition-transform duration-250 group-hover:translate-x-1" 
              />
            </button>

            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-4 rounded-xl bg-transparent border-2 border-primary-foreground/30 text-primary-foreground font-medium text-base hover:bg-primary-foreground/10 hover:border-primary-foreground/50 transition-all duration-250 touch-target"
            >
              <Icon name="ArrowUp" size={20} />
              <span>Back to Top</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-8 pt-8 md:pt-12 text-sm text-primary-foreground/80">
            <div className="flex items-center space-x-2">
              <Icon name="Check" size={16} />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Check" size={16} />
              <span>Free forever</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Check" size={16} />
              <span>Start in seconds</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;