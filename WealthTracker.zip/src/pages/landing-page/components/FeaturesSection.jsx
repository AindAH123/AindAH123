import React from 'react';
import Icon from '../../../components/AppIcon';

const FeaturesSection = () => {
  const features = [
    {
      icon: 'Calculator',
      title: 'Wealth Impact Calculator',
      description: 'See exactly how much your recurring expenses cost you in lost investment opportunities over time'
    },
    {
      icon: 'PieChart',
      title: 'Category Breakdown',
      description: 'Understand where your money goes with visual charts showing spending patterns by category'
    },
    {
      icon: 'Repeat',
      title: 'Dream Swap Tool',
      description: 'Calculate how quickly you can reach financial goals by cutting specific expenses'
    },
    {
      icon: 'BarChart3',
      title: 'Analytics Dashboard',
      description: 'Get detailed insights into your top expenses and their long-term wealth impact'
    },
    {
      icon: 'Settings',
      title: 'Custom Assumptions',
      description: 'Adjust investment returns and inflation rates to match your financial strategy'
    },
    {
      icon: 'Lightbulb',
      title: 'Smart Recommendations',
      description: 'Receive personalized suggestions for optimizing your spending and saving habits'
    }
  ];

  return (
    <section className="py-16 md:py-24 lg:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16 animate-in">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Powerful Features for Financial Clarity
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to understand and optimize your financial future
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {features?.map((feature, index) => (
            <div
              key={index}
              className="bg-card rounded-2xl p-6 md:p-8 shadow-md hover:shadow-lg transition-all duration-250 hover:-translate-y-1 border border-border animate-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 md:mb-6">
                <Icon name={feature?.icon} size={24} className="text-primary md:w-7 md:h-7" />
              </div>
              
              <h3 className="text-lg md:text-xl font-semibold text-foreground mb-2 md:mb-3">
                {feature?.title}
              </h3>
              
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                {feature?.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;