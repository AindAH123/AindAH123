import React from 'react';
import Icon from '../../../components/AppIcon';

const HeroSection = ({ onGetStarted, onTrySample }) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-16 md:py-24 lg:py-32">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(45,90,61,0.08),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(74,124,89,0.06),transparent_50%)]" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 md:space-y-8 animate-in">
          <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
            <Icon name="TrendingUp" size={16} className="text-primary" />
            <span className="text-sm font-medium text-primary">Smart Financial Planning</span>
          </div>

          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground max-w-4xl mx-auto leading-tight">
            See How Your Daily Expenses Impact Your{' '}
            <span className="text-primary">Long-Term Wealth</span>
          </h1>

          <p className="text-base md:text-lg lg:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Track recurring subscriptions and habits, then visualize how much wealth you could accumulate by investing that money instead. Make informed financial decisions with clear, actionable insights.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 md:pt-6">
            <button
              onClick={onGetStarted}
              className="group w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-4 rounded-xl bg-primary text-primary-foreground font-medium text-base shadow-lg hover:shadow-xl transition-all duration-250 hover:-translate-y-0.5 touch-target"
            >
              <span>Get Started</span>
              <Icon 
                name="ArrowRight" 
                size={20} 
                className="transition-transform duration-250 group-hover:translate-x-1" 
              />
            </button>

            <button
              onClick={onTrySample}
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-4 rounded-xl bg-card border-2 border-primary/20 text-foreground font-medium text-base hover:bg-primary/5 hover:border-primary/40 transition-all duration-250 touch-target"
            >
              <Icon name="Sparkles" size={20} className="text-primary" />
              <span>Try Sample Data</span>
            </button>
          </div>

          <div className="flex items-center justify-center space-x-8 pt-8 md:pt-12 text-sm text-muted-foreground">
            <div className="flex items-center space-x-2">
              <Icon name="Shield" size={16} className="text-primary" />
              <span>No signup required</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Lock" size={16} className="text-primary" />
              <span>Privacy focused</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;