import React from 'react';
import Icon from '../../../components/AppIcon';

const StepFlowCard = ({ step, icon, title, description, isLast }) => {
  return (
    <div className="relative flex flex-col items-center text-center animate-in stagger-1">
      <div className="relative">
        <div className="w-16 h-16 md:w-20 md:h-20 lg:w-24 lg:h-24 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg mb-4 md:mb-6">
          <Icon name={icon} size={32} color="white" strokeWidth={2} className="md:w-10 md:h-10 lg:w-12 lg:h-12" />
        </div>
        
        <div className="absolute -top-2 -right-2 w-8 h-8 md:w-10 md:h-10 rounded-full bg-accent text-accent-foreground flex items-center justify-center font-bold text-sm md:text-base shadow-md">
          {step}
        </div>
      </div>

      <h3 className="text-lg md:text-xl lg:text-2xl font-semibold text-foreground mb-2 md:mb-3">
        {title}
      </h3>

      <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-xs">
        {description}
      </p>

      {!isLast && (
        <div className="hidden lg:block absolute top-12 -right-16 xl:-right-20">
          <Icon name="ArrowRight" size={32} className="text-primary/30" strokeWidth={2} />
        </div>
      )}

      {!isLast && (
        <div className="lg:hidden mt-6 mb-2">
          <Icon name="ArrowDown" size={24} className="text-primary/30" strokeWidth={2} />
        </div>
      )}
    </div>
  );
};

export default StepFlowCard;