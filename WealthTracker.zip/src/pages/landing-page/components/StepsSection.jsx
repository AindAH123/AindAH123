import React from 'react';
import StepFlowCard from './StepFlowCard';

const StepsSection = () => {
  const steps = [
    {
      step: 1,
      icon: 'PlusCircle',
      title: 'Track Your Expenses',
      description: 'Add your recurring subscriptions and daily habits with their costs and frequency'
    },
    {
      step: 2,
      icon: 'TrendingUp',
      title: 'See Projections',
      description: 'Visualize how much wealth you could accumulate by investing that money over 30 years'
    },
    {
      step: 3,
      icon: 'Target',
      title: 'Make Decisions',
      description: 'Use insights to cut unnecessary expenses and redirect funds toward your financial goals'
    }
  ];

  return (
    <section className="py-16 md:py-24 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16 lg:mb-20 animate-in">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            Three simple steps to understand your financial future
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 xl:gap-16 max-w-6xl mx-auto">
          {steps?.map((step, index) => (
            <StepFlowCard
              key={step?.step}
              step={step?.step}
              icon={step?.icon}
              title={step?.title}
              description={step?.description}
              isLast={index === steps?.length - 1}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default StepsSection;