import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import HeroSection from './components/HeroSection';
import StepsSection from './components/StepsSection';
import FeaturesSection from './components/FeaturesSection';
import CTASection from './components/CTASection';

const LandingPage = () => {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleGetStarted = () => {
    navigate('/main-dashboard', { state: { scrollToOnboarding: true } });
  };

  const handleTrySample = () => {
    navigate('/main-dashboard', { state: { loadSampleData: true } });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <HeroSection 
          onGetStarted={handleGetStarted}
          onTrySample={handleTrySample}
        />
        
        <StepsSection />
        
        <FeaturesSection />
        
        <CTASection onGetStarted={handleGetStarted} />
      </main>
      <footer className="bg-card border-t border-border py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4">
            <p className="text-sm md:text-base text-muted-foreground">
              &copy; {new Date()?.getFullYear()} The Guillotine. All rights reserved.
            </p>
            <p className="text-xs md:text-sm text-muted-foreground">
              Investment projections are estimates based on historical averages and do not guarantee future results.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;