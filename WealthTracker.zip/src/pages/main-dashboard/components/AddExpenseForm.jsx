import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const AddExpenseForm = ({ onAddExpense }) => {
  const [formData, setFormData] = useState({
    name: '',
    amount: '',
    frequency: 'monthly',
    type: 'subscription',
    category: 'entertainment'
  });
  
  const [errors, setErrors] = useState({});

  const frequencyOptions = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' },
    { value: 'yearly', label: 'Yearly' }
  ];

  const typeOptions = [
    { value: 'subscription', label: 'Subscription' },
    { value: 'habit', label: 'Habit' }
  ];

  const categoryOptions = [
    { value: 'entertainment', label: 'Entertainment' },
    { value: 'food', label: 'Food & Dining' },
    { value: 'shopping', label: 'Shopping' },
    { value: 'transportation', label: 'Transportation' },
    { value: 'health', label: 'Health & Fitness' },
    { value: 'utilities', label: 'Utilities' },
    { value: 'other', label: 'Other' }
  ];

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData?.name?.trim()) {
      newErrors.name = 'Expense name is required';
    }
    
    if (!formData?.amount || parseFloat(formData?.amount) <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    
    if (validateForm()) {
      onAddExpense({
        id: Date.now(),
        name: formData?.name?.trim(),
        amount: parseFloat(formData?.amount),
        frequency: formData?.frequency,
        type: formData?.type,
        category: formData?.category,
        createdAt: new Date()?.toISOString()
      });
      
      setFormData({
        name: '',
        amount: '',
        frequency: 'monthly',
        type: 'subscription',
        category: 'entertainment'
      });
      setErrors({});
    }
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon name="Plus" size={20} className="text-primary" />
        </div>
        <h2 className="text-xl md:text-2xl font-semibold text-foreground">
          Add Expense
        </h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-5">
        <Input
          label="Expense Name"
          type="text"
          placeholder="e.g., Netflix, Daily Coffee"
          value={formData?.name}
          onChange={(e) => handleChange('name', e?.target?.value)}
          error={errors?.name}
          required
        />

        <Input
          label="Amount"
          type="number"
          placeholder="0.00"
          value={formData?.amount}
          onChange={(e) => handleChange('amount', e?.target?.value)}
          error={errors?.amount}
          required
          min="0.01"
          step="0.01"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <Select
            label="Frequency"
            options={frequencyOptions}
            value={formData?.frequency}
            onChange={(value) => handleChange('frequency', value)}
            required
          />

          <Select
            label="Type"
            options={typeOptions}
            value={formData?.type}
            onChange={(value) => handleChange('type', value)}
            required
          />
        </div>

        <Select
          label="Category"
          options={categoryOptions}
          value={formData?.category}
          onChange={(value) => handleChange('category', value)}
          required
        />

        <Button
          type="submit"
          variant="default"
          fullWidth
          iconName="Plus"
          iconPosition="left"
          className="mt-6"
        >
          Add Expense
        </Button>
      </form>
    </div>
  );
};

export default AddExpenseForm;