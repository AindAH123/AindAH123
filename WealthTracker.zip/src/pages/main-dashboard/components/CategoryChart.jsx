import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import Icon from '../../../components/AppIcon';

const CategoryChart = ({ expenses }) => {
  const categoryColors = {
    entertainment: '#2D5A3D',
    food: '#4A7C59',
    shopping: '#D4A574',
    transportation: '#B8935F',
    health: '#059669',
    utilities: '#10B981',
    other: '#6B7280'
  };

  const calculateCategoryData = () => {
    const categoryTotals = {};
    
    expenses?.forEach(expense => {
      const monthlyAmount = convertToMonthly(expense?.amount, expense?.frequency);
      categoryTotals[expense.category] = (categoryTotals?.[expense?.category] || 0) + monthlyAmount;
    });

    return Object.entries(categoryTotals)?.map(([category, value]) => ({
      name: category?.charAt(0)?.toUpperCase() + category?.slice(1),
      value: parseFloat(value?.toFixed(2)),
      color: categoryColors?.[category] || categoryColors?.other
    }));
  };

  const convertToMonthly = (amount, frequency) => {
    const conversions = {
      daily: amount * 30,
      weekly: amount * 4.33,
      monthly: amount,
      yearly: amount / 12
    };
    return conversions?.[frequency] || amount;
  };

  const data = calculateCategoryData();

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      const value = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      })?.format(payload?.[0]?.value);
      
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="text-sm font-medium text-foreground">{payload?.[0]?.name}</p>
          <p className="data-text text-base font-semibold text-primary mt-1">{value}/mo</p>
        </div>
      );
    }
    return null;
  };

  if (data?.length === 0) {
    return (
      <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon name="PieChart" size={20} className="text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground">
            Spending by Category
          </h2>
        </div>
        
        <div className="flex flex-col items-center justify-center py-12 md:py-16">
          <Icon name="PieChart" size={48} className="text-muted-foreground mb-4" />
          <p className="text-base text-muted-foreground text-center">
            Add expenses to see category breakdown
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon name="PieChart" size={20} className="text-primary" />
        </div>
        <h2 className="text-xl md:text-2xl font-semibold text-foreground">
          Spending by Category
        </h2>
      </div>
      <div className="w-full h-64 md:h-80 lg:h-96" aria-label="Category spending breakdown pie chart">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius="80%"
              fill="#8884d8"
              dataKey="value"
            >
              {data?.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry?.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              iconType="circle"
              wrapperStyle={{ paddingTop: '20px' }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CategoryChart;