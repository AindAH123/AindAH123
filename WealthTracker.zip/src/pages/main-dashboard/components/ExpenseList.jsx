import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ExpenseList = ({ expenses, onDeleteExpense }) => {
  const subscriptions = expenses?.filter(exp => exp?.type === 'subscription');
  const habits = expenses?.filter(exp => exp?.type === 'habit');

  const formatAmount = (amount, frequency) => {
    const formatted = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
    
    return `${formatted}/${frequency}`;
  };

  const getCategoryIcon = (category) => {
    const icons = {
      entertainment: 'Tv',
      food: 'Coffee',
      shopping: 'ShoppingBag',
      transportation: 'Car',
      health: 'Heart',
      utilities: 'Zap',
      other: 'DollarSign'
    };
    return icons?.[category] || 'DollarSign';
  };

  const ExpenseCard = ({ expense }) => (
    <div className="bg-muted/50 rounded-xl p-4 md:p-5 border border-border hover:border-primary/30 transition-all duration-250 group">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start space-x-3 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Icon name={getCategoryIcon(expense?.category)} size={20} className="text-primary" />
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className="text-base md:text-lg font-medium text-foreground text-truncate">
              {expense?.name}
            </h4>
            <p className="text-sm text-muted-foreground capitalize mt-1">
              {expense?.category}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3 flex-shrink-0">
          <div className="text-right">
            <p className="data-text text-base md:text-lg font-semibold text-foreground whitespace-nowrap">
              {formatAmount(expense?.amount, expense?.frequency)}
            </p>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDeleteExpense(expense?.id)}
            className="opacity-0 group-hover:opacity-100 transition-opacity duration-250"
            iconName="Trash2"
          >
            <span className="sr-only">Delete {expense?.name}</span>
          </Button>
        </div>
      </div>
    </div>
  );

  const ExpenseSection = ({ title, items, icon }) => (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Icon name={icon} size={20} className="text-primary" />
        <h3 className="text-lg md:text-xl font-semibold text-foreground">
          {title}
        </h3>
        <span className="data-text text-sm text-muted-foreground">
          ({items?.length})
        </span>
      </div>
      
      {items?.length === 0 ? (
        <div className="bg-muted/30 rounded-xl p-8 text-center border border-dashed border-border">
          <Icon name="Inbox" size={32} className="text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">
            No {title?.toLowerCase()} added yet
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {items?.map(expense => (
            <ExpenseCard key={expense?.id} expense={expense} />
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md space-y-8">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon name="List" size={20} className="text-primary" />
        </div>
        <h2 className="text-xl md:text-2xl font-semibold text-foreground">
          Your Expenses
        </h2>
      </div>

      <ExpenseSection title="Subscriptions" items={subscriptions} icon="CreditCard" />
      <ExpenseSection title="Habits" items={habits} icon="Coffee" />
    </div>
  );
};

export default ExpenseList;