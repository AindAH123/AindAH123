import React from 'react';
import Icon from '../../../components/AppIcon';

const KeyMetrics = ({ totalMonthly, wealthLost, investmentType, annualReturn }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(amount);
  };

  const getInvestmentLabel = () => {
    const labels = {
      conservative: 'Conservative (4-6% annual)',
      moderate: 'Moderate (6-8% annual)',
      aggressive: 'Aggressive (8-10% annual)'
    };
    return labels?.[investmentType] || `Custom (${annualReturn}% annual)`;
  };

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Icon name="TrendingDown" size={20} className="text-primary" />
            </div>
            <div>
              <h3 className="text-base md:text-lg font-semibold text-foreground">
                Monthly Spending
              </h3>
              <p className="text-xs md:text-sm text-muted-foreground mt-1">
                Total recurring expenses
              </p>
            </div>
          </div>
        </div>
        
        <p className="data-text text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">
          {formatCurrency(totalMonthly)}
        </p>
        
        <p className="text-xs md:text-sm text-muted-foreground mt-3">
          per month
        </p>
      </div>

      <div className="bg-gradient-to-br from-destructive/10 via-destructive/5 to-transparent rounded-2xl border-2 border-destructive/20 p-6 md:p-8 shadow-md">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-destructive/20 flex items-center justify-center">
              <Icon name="AlertTriangle" size={20} className="text-destructive" />
            </div>
            <div>
              <h3 className="text-base md:text-lg font-semibold text-foreground">
                30-Year Wealth Lost
              </h3>
              <p className="text-xs md:text-sm text-muted-foreground mt-1">
                If invested instead
              </p>
            </div>
          </div>
        </div>
        
        <p className="data-text text-3xl md:text-4xl lg:text-5xl font-bold text-destructive">
          {formatCurrency(wealthLost)}
        </p>
        
        <div className="mt-4 pt-4 border-t border-destructive/20">
          <div className="flex items-center space-x-2 text-xs md:text-sm text-muted-foreground">
            <Icon name="Info" size={16} />
            <span>Assuming {getInvestmentLabel()}</span>
          </div>
        </div>
      </div>

      <div className="bg-muted/50 rounded-xl p-4 md:p-5 border border-border">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={20} className="text-primary flex-shrink-0 mt-0.5" />
          <div className="space-y-2">
            <p className="text-sm md:text-base text-foreground font-medium">
              Investment Insight
            </p>
            <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
              By cutting these expenses and investing the money, you could potentially build significant wealth over time through compound growth.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KeyMetrics;