import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const OnboardingPanel = ({ onDismiss }) => {
  return (
    <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent rounded-2xl border-2 border-primary/20 p-6 md:p-8 lg:p-10 mb-6 md:mb-8 animate-in">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="flex-1 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Icon name="Sparkles" size={24} className="text-primary" />
            </div>
            <h2 className="text-2xl md:text-3xl font-semibold text-foreground">
              Start Here
            </h2>
          </div>
          
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl">
            Welcome to The Guillotine! Add your first recurring expense below to see how much wealth you could build by cutting it. We'll show you the 30-year impact of investing that money instead.
          </p>
          
          <div className="flex flex-wrap gap-3 pt-2">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="CheckCircle2" size={18} className="text-success" />
              <span>Track subscriptions &amp; habits</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="CheckCircle2" size={18} className="text-success" />
              <span>See long-term wealth impact</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Icon name="CheckCircle2" size={18} className="text-success" />
              <span>Make informed decisions</span>
            </div>
          </div>
        </div>
        
        <Button
          variant="ghost"
          size="icon"
          onClick={onDismiss}
          className="self-start lg:self-center"
          iconName="X"
        >
          <span className="sr-only">Dismiss onboarding</span>
        </Button>
      </div>
    </div>
  );
};

export default OnboardingPanel;