import React from 'react';
import Icon from '../../../components/AppIcon';

const SpendingLimitAlerts = ({ expenses, limits }) => {
  const convertToMonthly = (amount, frequency) => {
    const conversions = {
      daily: amount * 30,
      weekly: amount * 4.33,
      monthly: amount,
      yearly: amount / 12
    };
    return conversions?.[frequency] || amount;
  };

  const calculateCategorySpending = () => {
    const categoryTotals = {};
    
    expenses?.forEach(expense => {
      const monthlyAmount = convertToMonthly(expense?.amount, expense?.frequency);
      categoryTotals[expense?.category] = (categoryTotals?.[expense?.category] || 0) + monthlyAmount;
    });

    return categoryTotals;
  };

  const getAlerts = () => {
    const categorySpending = calculateCategorySpending();
    const alerts = [];

    Object.entries(limits)?.forEach(([category, limit]) => {
      const spent = categorySpending?.[category] || 0;
      const percentage = (spent / limit) * 100;

      if (percentage >= 100) {
        alerts?.push({
          category,
          spent,
          limit,
          percentage,
          severity: 'critical',
          message: 'Limit exceeded'
        });
      } else if (percentage >= 80) {
        alerts?.push({
          category,
          spent,
          limit,
          percentage,
          severity: 'warning',
          message: 'Approaching limit'
        });
      }
    });

    return alerts?.sort((a, b) => b?.percentage - a?.percentage);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  const getCategoryLabel = (category) => {
    const labels = {
      entertainment: 'Entertainment',
      food: 'Food & Dining',
      shopping: 'Shopping',
      transportation: 'Transportation',
      health: 'Health & Fitness',
      utilities: 'Utilities',
      other: 'Other'
    };
    return labels?.[category] || category;
  };

  const getSeverityStyles = (severity) => {
    if (severity === 'critical') {
      return {
        bg: 'bg-red-50',
        border: 'border-red-200',
        icon: 'bg-red-100',
        iconColor: 'text-red-600',
        text: 'text-red-900',
        badge: 'bg-red-100 text-red-700',
        progress: 'bg-red-500'
      };
    }
    return {
      bg: 'bg-amber-50',
      border: 'border-amber-200',
      icon: 'bg-amber-100',
      iconColor: 'text-amber-600',
      text: 'text-amber-900',
      badge: 'bg-amber-100 text-amber-700',
      progress: 'bg-amber-500'
    };
  };

  const alerts = getAlerts();

  if (alerts?.length === 0) {
    return null;
  }

  return (
    <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
          <Icon name="AlertTriangle" size={20} className="text-red-600" />
        </div>
        <h2 className="text-xl md:text-2xl font-semibold text-foreground">
          Spending Alerts
        </h2>
        <span className="data-text px-2.5 py-1 rounded-full bg-red-100 text-red-700 text-sm font-medium">
          {alerts?.length}
        </span>
      </div>

      <div className="space-y-4">
        {alerts?.map((alert, index) => {
          const styles = getSeverityStyles(alert?.severity);
          
          return (
            <div 
              key={`${alert?.category}-${index}`}
              className={`${styles?.bg} ${styles?.border} border rounded-xl p-5 transition-all duration-250`}
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-start space-x-3 flex-1">
                  <div className={`w-10 h-10 rounded-lg ${styles?.icon} flex items-center justify-center flex-shrink-0`}>
                    <Icon 
                      name={alert?.severity === 'critical' ? 'XCircle' : 'AlertCircle'} 
                      size={20} 
                      className={styles?.iconColor} 
                    />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className={`text-base md:text-lg font-semibold ${styles?.text}`}>
                        {getCategoryLabel(alert?.category)}
                      </h3>
                      <span className={`data-text px-2 py-0.5 rounded-full ${styles?.badge} text-xs font-medium`}>
                        {alert?.message}
                      </span>
                    </div>
                    
                    <p className={`text-sm ${styles?.text} opacity-80`}>
                      {formatCurrency(alert?.spent)} of {formatCurrency(alert?.limit)} spent
                    </p>
                  </div>
                </div>
                
                <div className="text-right flex-shrink-0">
                  <p className={`data-text text-2xl font-bold ${styles?.text}`}>
                    {Math.round(alert?.percentage)}%
                  </p>
                </div>
              </div>

              <div className="w-full bg-white/50 rounded-full h-2.5 overflow-hidden">
                <div 
                  className={`${styles?.progress} h-full rounded-full transition-all duration-500`}
                  style={{ width: `${Math.min(alert?.percentage, 100)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SpendingLimitAlerts;