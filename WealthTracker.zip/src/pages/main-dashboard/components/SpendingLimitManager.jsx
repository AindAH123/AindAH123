import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const SpendingLimitManager = ({ limits, onUpdateLimits }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [limitValue, setLimitValue] = useState('');

  const categoryOptions = [
    { value: 'entertainment', label: 'Entertainment' },
    { value: 'food', label: 'Food & Dining' },
    { value: 'shopping', label: 'Shopping' },
    { value: 'transportation', label: 'Transportation' },
    { value: 'health', label: 'Health & Fitness' },
    { value: 'utilities', label: 'Utilities' },
    { value: 'other', label: 'Other' }
  ];

  const handleSetLimit = () => {
    if (editingCategory && limitValue && parseFloat(limitValue) > 0) {
      onUpdateLimits({
        ...limits,
        [editingCategory]: parseFloat(limitValue)
      });
      setEditingCategory(null);
      setLimitValue('');
    }
  };

  const handleRemoveLimit = (category) => {
    const newLimits = { ...limits };
    delete newLimits?.[category];
    onUpdateLimits(newLimits);
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    })?.format(amount);
  };

  const getCategoryLabel = (category) => {
    return categoryOptions?.find(opt => opt?.value === category)?.label || category;
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
      <div 
        className="flex items-center justify-between cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon name="AlertCircle" size={20} className="text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground">
            Spending Limits
          </h2>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={24} 
          className="text-muted-foreground" 
        />
      </div>

      {isExpanded && (
        <div className="mt-6 space-y-6">
          <div className="space-y-4">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              Active Limits
            </h3>
            
            {Object.keys(limits)?.length === 0 ? (
              <div className="bg-muted/30 rounded-xl p-6 text-center border border-dashed border-border">
                <Icon name="Target" size={32} className="text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No spending limits set yet
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {Object.entries(limits)?.map(([category, limit]) => (
                  <div 
                    key={category}
                    className="flex items-center justify-between bg-muted/50 rounded-lg p-4 border border-border"
                  >
                    <div>
                      <p className="text-base font-medium text-foreground">
                        {getCategoryLabel(category)}
                      </p>
                      <p className="data-text text-sm text-muted-foreground mt-1">
                        Monthly limit: {formatCurrency(limit)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveLimit(category)}
                      iconName="X"
                    >
                      <span className="sr-only">Remove limit</span>
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="border-t border-border pt-6">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Add New Limit
            </h3>
            
            <div className="space-y-4">
              <Select
                label="Category"
                options={categoryOptions?.filter(opt => !limits?.[opt?.value])}
                value={editingCategory || ''}
                onChange={(value) => setEditingCategory(value)}
                placeholder="Select category"
              />

              <Input
                label="Monthly Limit"
                type="number"
                placeholder="0.00"
                value={limitValue}
                onChange={(e) => setLimitValue(e?.target?.value)}
                min="0.01"
                step="0.01"
                disabled={!editingCategory}
              />

              <Button
                variant="default"
                fullWidth
                onClick={handleSetLimit}
                disabled={!editingCategory || !limitValue || parseFloat(limitValue) <= 0}
                iconName="Check"
                iconPosition="left"
              >
                Set Limit
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SpendingLimitManager;