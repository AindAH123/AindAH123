import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import Icon from '../../../components/AppIcon';

const WealthGrowthChart = ({ totalMonthly, annualReturn }) => {
  const calculateWealthGrowth = () => {
    const data = [];
    const monthlyRate = annualReturn / 100 / 12;
    let balance = 0;

    for (let year = 0; year <= 30; year++) {
      if (year === 0) {
        data?.push({
          year: year,
          wealth: 0,
          invested: 0
        });
      } else {
        const months = year * 12;
        balance = 0;
        
        for (let month = 1; month <= months; month++) {
          balance = (balance + totalMonthly) * (1 + monthlyRate);
        }
        
        data?.push({
          year: year,
          wealth: parseFloat(balance?.toFixed(2)),
          invested: totalMonthly * months
        });
      }
    }

    return data;
  };

  const data = calculateWealthGrowth();

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-4 shadow-lg">
          <p className="text-sm font-medium text-foreground mb-2">Year {label}</p>
          <div className="space-y-1">
            <p className="data-text text-sm text-primary">
              Wealth: {formatCurrency(payload?.[0]?.value)}
            </p>
            <p className="data-text text-sm text-muted-foreground">
              Invested: {formatCurrency(payload?.[1]?.value)}
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  if (totalMonthly === 0) {
    return (
      <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon name="TrendingUp" size={20} className="text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground">
            30-Year Wealth Growth
          </h2>
        </div>
        
        <div className="flex flex-col items-center justify-center py-12 md:py-16">
          <Icon name="TrendingUp" size={48} className="text-muted-foreground mb-4" />
          <p className="text-base text-muted-foreground text-center">
            Add expenses to see wealth projection
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-md">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon name="TrendingUp" size={20} className="text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground">
            30-Year Wealth Growth
          </h2>
        </div>
        
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Icon name="Info" size={16} />
          <span>Compound growth at {annualReturn}% annual return</span>
        </div>
      </div>

      <div className="w-full h-64 md:h-80 lg:h-96" aria-label="30-year wealth growth projection line chart">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              dataKey="year" 
              stroke="var(--color-muted-foreground)"
              tick={{ fill: 'var(--color-muted-foreground)' }}
              label={{ value: 'Years', position: 'insideBottom', offset: -5 }}
            />
            <YAxis 
              stroke="var(--color-muted-foreground)"
              tick={{ fill: 'var(--color-muted-foreground)' }}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              verticalAlign="top" 
              height={36}
              iconType="line"
            />
            <Line 
              type="monotone" 
              dataKey="wealth" 
              stroke="var(--color-primary)" 
              strokeWidth={3}
              dot={false}
              name="Potential Wealth"
            />
            <Line 
              type="monotone" 
              dataKey="invested" 
              stroke="var(--color-muted-foreground)" 
              strokeWidth={2}
              strokeDasharray="5 5"
              dot={false}
              name="Total Invested"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default WealthGrowthChart;