import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Breadcrumbs from '../../components/ui/Breadcrumbs';
import OnboardingPanel from './components/OnboardingPanel';
import AddExpenseForm from './components/AddExpenseForm';
import ExpenseList from './components/ExpenseList';
import KeyMetrics from './components/KeyMetrics';
import CategoryChart from './components/CategoryChart';
import WealthGrowthChart from './components/WealthGrowthChart';
import SpendingLimitManager from './components/SpendingLimitManager';
import SpendingLimitAlerts from './components/SpendingLimitAlerts';
import { getExpenses, saveExpenses, getSettings, getSpendingLimits, saveSpendingLimits } from '../../utils/globalState';

const MainDashboard = () => {
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [expenses, setExpenses] = useState([]);
  const [spendingLimits, setSpendingLimits] = useState({});
  const [investmentSettings, setInvestmentSettings] = useState({
    type: 'moderate',
    annualReturn: 7,
    inflationEnabled: false,
    inflationRate: 3
  });

  useEffect(() => {
    const hasVisited = sessionStorage.getItem('hasVisitedDashboard');
    if (hasVisited) {
      setShowOnboarding(false);
    }

    // Load expenses from localStorage
    const savedExpenses = getExpenses();
    setExpenses(savedExpenses);

    // Load settings from localStorage
    const savedSettings = getSettings();
    setInvestmentSettings(savedSettings);

    // Load spending limits from localStorage
    const savedLimits = getSpendingLimits();
    setSpendingLimits(savedLimits);

    // Listen for settings updates from other pages
    const handleSettingsUpdate = (event) => {
      setInvestmentSettings(event?.detail);
    };

    window.addEventListener('settingsUpdated', handleSettingsUpdate);

    return () => {
      window.removeEventListener('settingsUpdated', handleSettingsUpdate);
    };
  }, []);

  const handleDismissOnboarding = () => {
    setShowOnboarding(false);
    sessionStorage.setItem('hasVisitedDashboard', 'true');
  };

  const handleAddExpense = (expense) => {
    const updatedExpenses = [...expenses, expense];
    setExpenses(updatedExpenses);
    saveExpenses(updatedExpenses);
  };

  const handleDeleteExpense = (id) => {
    const updatedExpenses = expenses?.filter(exp => exp?.id !== id);
    setExpenses(updatedExpenses);
    saveExpenses(updatedExpenses);
  };

  const handleUpdateLimits = (newLimits) => {
    setSpendingLimits(newLimits);
    saveSpendingLimits(newLimits);
  };

  const convertToMonthly = (amount, frequency) => {
    const conversions = {
      daily: amount * 30,
      weekly: amount * 4.33,
      monthly: amount,
      yearly: amount / 12
    };
    return conversions?.[frequency] || amount;
  };

  const calculateTotalMonthly = () => {
    return expenses?.reduce((total, expense) => {
      return total + convertToMonthly(expense?.amount, expense?.frequency);
    }, 0);
  };

  const calculateWealthLost = () => {
    const monthlyAmount = calculateTotalMonthly();
    const monthlyRate = investmentSettings?.annualReturn / 100 / 12;
    const months = 30 * 12;
    
    let futureValue = 0;
    for (let month = 1; month <= months; month++) {
      futureValue = (futureValue + monthlyAmount) * (1 + monthlyRate);
    }
    
    return futureValue;
  };

  const totalMonthly = calculateTotalMonthly();
  const wealthLost = calculateWealthLost();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="main-content">
        <div className="content-container">
          <Breadcrumbs />
          
          {showOnboarding && expenses?.length === 0 && (
            <OnboardingPanel onDismiss={handleDismissOnboarding} />
          )}

          <SpendingLimitAlerts expenses={expenses} limits={spendingLimits} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 mb-6 md:mb-8">
            <div className="lg:col-span-2 space-y-6 md:space-y-8">
              <AddExpenseForm onAddExpense={handleAddExpense} />
              <ExpenseList expenses={expenses} onDeleteExpense={handleDeleteExpense} />
            </div>

            <div className="lg:col-span-1 space-y-6 md:space-y-8">
              <KeyMetrics
                totalMonthly={totalMonthly}
                wealthLost={wealthLost}
                investmentType={investmentSettings?.type}
                annualReturn={investmentSettings?.annualReturn}
              />
              <SpendingLimitManager 
                limits={spendingLimits} 
                onUpdateLimits={handleUpdateLimits} 
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
            <CategoryChart expenses={expenses} />
            <WealthGrowthChart
              totalMonthly={totalMonthly}
              annualReturn={investmentSettings?.annualReturn}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default MainDashboard;