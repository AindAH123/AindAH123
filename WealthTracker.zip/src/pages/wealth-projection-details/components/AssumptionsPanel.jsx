import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import { saveSettings } from '../../../utils/globalState';

const AssumptionsPanel = ({ settings }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localSettings, setLocalSettings] = useState(settings);

  const getInvestmentTypeLabel = (type) => {
    const labels = {
      'conservative': 'Conservative (4-6% annual return)',
      'moderate': 'Moderate (6-8% annual return)',
      'aggressive': 'Aggressive (8-10% annual return)'
    };
    return labels?.[type] || type;
  };

  const getAnnualReturn = (type) => {
    const returns = {
      'conservative': 5,
      'moderate': 7,
      'aggressive': 9
    };
    return returns?.[type] || 7;
  };

  const handleSaveSettings = () => {
    const updatedSettings = {
      ...localSettings,
      annualReturn: getAnnualReturn(localSettings?.investmentType)
    };
    saveSettings(updatedSettings);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setLocalSettings(settings);
    setIsEditing(false);
  };

  const investmentOptions = [
    { value: 'conservative', label: 'Conservative' },
    { value: 'moderate', label: 'Moderate' },
    { value: 'aggressive', label: 'Aggressive' }
  ];

  return (
    <div className="card bg-muted/50">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Icon name="Settings" size={20} color="var(--color-primary)" />
            </div>
            <h3 className="text-lg md:text-xl font-semibold text-foreground">
              {isEditing ? 'Edit Settings' : 'Projection Settings'}
            </h3>
          </div>
          {!isEditing && (
            <Button
              variant="outline"
              size="sm"
              iconName="Edit"
              onClick={() => setIsEditing(true)}
            >
              Edit
            </Button>
          )}
        </div>

        {isEditing ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Investment Strategy
              </label>
              <Select
                options={investmentOptions}
                value={localSettings?.investmentType}
                onChange={(value) => setLocalSettings(prev => ({ ...prev, investmentType: value }))}
                placeholder="Select strategy"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Inflation Rate (%)
              </label>
              <Input
                type="number"
                value={localSettings?.inflationRate}
                onChange={(e) => setLocalSettings(prev => ({ ...prev, inflationRate: parseFloat(e?.target?.value) || 0 }))}
                min="0"
                max="20"
                step="0.1"
              />
            </div>

            <div className="flex space-x-2 pt-2">
              <Button
                variant="default"
                size="sm"
                onClick={handleSaveSettings}
                className="flex-1"
              >
                Save Changes
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCancel}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-start justify-between py-3 border-b border-border">
              <div className="space-y-1">
                <p className="text-sm md:text-base font-medium text-foreground">Investment Strategy</p>
                <p className="text-xs md:text-sm text-muted-foreground">
                  {getInvestmentTypeLabel(settings?.investmentType)}
                </p>
              </div>
              <span className="text-lg font-semibold text-primary data-text">
                {getAnnualReturn(settings?.investmentType)}%
              </span>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-border">
              <div className="space-y-1">
                <p className="text-sm md:text-base font-medium text-foreground">Inflation Rate</p>
                <p className="text-xs md:text-sm text-muted-foreground">
                  Annual inflation adjustment
                </p>
              </div>
              <span className="text-lg font-semibold text-foreground data-text">
                {settings?.inflationRate}%
              </span>
            </div>

            <div className="flex items-start justify-between py-3">
              <div className="space-y-1">
                <p className="text-sm md:text-base font-medium text-foreground">Real Return</p>
                <p className="text-xs md:text-sm text-muted-foreground">
                  After inflation adjustment
                </p>
              </div>
              <span className="text-lg font-semibold text-success data-text">
                {(getAnnualReturn(settings?.investmentType) - settings?.inflationRate)?.toFixed(1)}%
              </span>
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-border">
          <p className="text-xs md:text-sm text-muted-foreground">
            These projections are based on your current settings and assume consistent monthly contributions. Actual results may vary based on market conditions and investment performance.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AssumptionsPanel;