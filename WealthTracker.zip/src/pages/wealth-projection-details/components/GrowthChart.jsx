import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const GrowthChart = ({ projectionData, investmentType }) => {
  const [hoveredYear, setHoveredYear] = useState(null);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-lg shadow-lg p-4">
          <p className="text-sm font-medium text-foreground mb-2">
            Year {payload?.[0]?.payload?.year}
          </p>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">
              Wealth Lost: <span className="font-semibold text-error data-text">{formatCurrency(payload?.[0]?.value)}</span>
            </p>
            <p className="text-xs text-muted-foreground">
              Monthly Spending: <span className="font-semibold text-foreground data-text">{formatCurrency(payload?.[0]?.payload?.monthlySpending)}</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="card">
      <div className="space-y-4 md:space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-2 md:space-y-0">
          <div>
            <h2 className="text-xl md:text-2xl lg:text-3xl font-semibold text-foreground">
              30-Year Wealth Growth Projection
            </h2>
            <p className="text-sm md:text-base text-muted-foreground mt-1">
              Visualizing the long-term impact of your recurring expenses
            </p>
          </div>
          <div className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-muted">
            <div className="w-3 h-3 rounded-full bg-primary"></div>
            <span className="text-xs md:text-sm text-muted-foreground caption">
              Investment: {investmentType}
            </span>
          </div>
        </div>

        <div className="w-full h-64 md:h-80 lg:h-96" aria-label="30-Year Wealth Growth Line Chart">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={projectionData}
              margin={{ top: 5, right: 10, left: 10, bottom: 5 }}
              onMouseMove={(e) => {
                if (e && e?.activePayload) {
                  setHoveredYear(e?.activePayload?.[0]?.payload?.year);
                }
              }}
              onMouseLeave={() => setHoveredYear(null)}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis 
                dataKey="year" 
                stroke="var(--color-muted-foreground)"
                tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                label={{ value: 'Years', position: 'insideBottom', offset: -5, fill: 'var(--color-muted-foreground)' }}
              />
              <YAxis 
                stroke="var(--color-muted-foreground)"
                tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                tickFormatter={(value) => `$${(value / 1000)?.toFixed(0)}k`}
                label={{ value: 'Wealth Lost ($)', angle: -90, position: 'insideLeft', fill: 'var(--color-muted-foreground)' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: '20px' }}
                iconType="circle"
              />
              <Line 
                type="monotone" 
                dataKey="wealthLost" 
                stroke="var(--color-primary)" 
                strokeWidth={3}
                dot={{ fill: 'var(--color-primary)', r: 4 }}
                activeDot={{ r: 6, fill: 'var(--color-accent)' }}
                name="Potential Wealth Lost"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-border">
          <div className="text-center">
            <p className="text-xs md:text-sm text-muted-foreground caption">Total Invested</p>
            <p className="text-lg md:text-xl font-semibold text-foreground data-text mt-1">
              {formatCurrency(projectionData?.[projectionData?.length - 1]?.totalInvested || 0)}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs md:text-sm text-muted-foreground caption">Investment Returns</p>
            <p className="text-lg md:text-xl font-semibold text-success data-text mt-1">
              {formatCurrency((projectionData?.[projectionData?.length - 1]?.wealthLost || 0) - (projectionData?.[projectionData?.length - 1]?.totalInvested || 0))}
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs md:text-sm text-muted-foreground caption">Total Wealth Lost</p>
            <p className="text-lg md:text-xl font-semibold text-error data-text mt-1">
              {formatCurrency(projectionData?.[projectionData?.length - 1]?.wealthLost || 0)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GrowthChart;