import React from 'react';
import Icon from '../../../components/AppIcon';

const MilestoneCard = ({ icon, title, amount, description, yearsToAchieve, isAchievable }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  return (
    <div className={`card ${isAchievable ? 'border-success/30' : 'border-muted'}`}>
      <div className="flex flex-col space-y-4">
        <div className="flex items-start justify-between">
          <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl flex items-center justify-center ${
            isAchievable ? 'bg-success/10' : 'bg-muted'
          }`}>
            <Icon 
              name={icon} 
              size={24} 
              color={isAchievable ? 'var(--color-success)' : 'var(--color-muted-foreground)'} 
            />
          </div>
          {isAchievable && (
            <div className="px-2 py-1 rounded-md bg-success/10">
              <span className="text-xs font-medium text-success caption">Achievable</span>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-lg md:text-xl font-semibold text-foreground">
            {title}
          </h3>
          <p className="text-2xl md:text-3xl font-bold text-foreground data-text">
            {formatCurrency(amount)}
          </p>
        </div>

        <p className="text-sm md:text-base text-muted-foreground line-clamp-2">
          {description}
        </p>

        <div className="pt-3 border-t border-border">
          <div className="flex items-center justify-between">
            <span className="text-xs md:text-sm text-muted-foreground caption">
              Time to achieve
            </span>
            <span className={`text-sm md:text-base font-semibold data-text ${
              isAchievable ? 'text-success' : 'text-muted-foreground'
            }`}>
              {yearsToAchieve} years
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MilestoneCard;