import React from 'react';

const ProjectionCard = ({ years, amount, growthPercentage, isHighlighted }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  return (
    <div className={`card ${isHighlighted ? 'ring-2 ring-primary' : ''}`}>
      <div className="flex flex-col space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm md:text-base text-muted-foreground caption">
            {years} Year{years > 1 ? 's' : ''}
          </span>
          {isHighlighted && (
            <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs md:text-sm font-medium caption">
              Primary Goal
            </span>
          )}
        </div>
        
        <div className="space-y-2">
          <h3 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground data-text">
            {formatCurrency(amount)}
          </h3>
          <div className="flex items-center space-x-2">
            <div className={`px-2 py-1 rounded-md ${
              growthPercentage >= 0 ? 'bg-success/10' : 'bg-error/10'
            }`}>
              <span className={`text-xs md:text-sm font-medium data-text ${
                growthPercentage >= 0 ? 'text-success' : 'text-error'
              }`}>
                {growthPercentage >= 0 ? '+' : ''}{growthPercentage?.toFixed(1)}%
              </span>
            </div>
            <span className="text-xs md:text-sm text-muted-foreground">
              potential wealth lost
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectionCard;