import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Breadcrumbs from '../../components/ui/Breadcrumbs';
import ProjectionCard from './components/ProjectionCard';
import GrowthChart from './components/GrowthChart';
import MilestoneCard from './components/MilestoneCard';
import AssumptionsPanel from './components/AssumptionsPanel';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { getExpenses, getSettings } from '../../utils/globalState';

const WealthProjectionDetails = () => {
  const navigate = useNavigate();
  const [settings, setSettings] = useState({
    investmentType: 'moderate',
    inflationRate: 3,
    theme: 'light'
  });
  const [expenses, setExpenses] = useState([]);
  const [monthlySpending, setMonthlySpending] = useState(0);

  useEffect(() => {
    window.scrollTo(0, 0);

    // Load expenses from localStorage
    const savedExpenses = getExpenses();
    setExpenses(savedExpenses);

    // Load settings from localStorage
    const savedSettings = getSettings();
    setSettings({
      investmentType: savedSettings?.investmentType || 'moderate',
      inflationRate: savedSettings?.inflationRate || 3,
      theme: 'light'
    });

    // Calculate total monthly spending from expenses
    const totalMonthly = calculateTotalMonthlyFromExpenses(savedExpenses);
    setMonthlySpending(totalMonthly);

    // Listen for expense and settings updates
    const handleExpensesUpdate = (event) => {
      const updatedExpenses = event?.detail;
      setExpenses(updatedExpenses);
      const totalMonthly = calculateTotalMonthlyFromExpenses(updatedExpenses);
      setMonthlySpending(totalMonthly);
    };

    const handleSettingsUpdate = (event) => {
      const updatedSettings = event?.detail;
      setSettings(prev => ({
        ...prev,
        investmentType: updatedSettings?.investmentType || prev?.investmentType,
        inflationRate: updatedSettings?.inflationRate || prev?.inflationRate
      }));
    };

    window.addEventListener('expensesUpdated', handleExpensesUpdate);
    window.addEventListener('settingsUpdated', handleSettingsUpdate);

    return () => {
      window.removeEventListener('expensesUpdated', handleExpensesUpdate);
      window.removeEventListener('settingsUpdated', handleSettingsUpdate);
    };
  }, []);

  const calculateTotalMonthlyFromExpenses = (expensesList) => {
    if (!expensesList || expensesList?.length === 0) return 0;
    
    return expensesList?.reduce((total, expense) => {
      const conversions = {
        daily: expense?.amount * 30,
        weekly: expense?.amount * 4.33,
        monthly: expense?.amount,
        yearly: expense?.amount / 12
      };
      return total + (conversions?.[expense?.frequency] || expense?.amount);
    }, 0);
  };

  const getAnnualReturn = (type) => {
    const returns = {
      'conservative': 5,
      'moderate': 7,
      'aggressive': 9
    };
    return returns?.[type] || 7;
  };

  const calculateFutureValue = (monthlyAmount, years, annualReturn) => {
    const monthlyRate = annualReturn / 12 / 100;
    const months = years * 12;
    
    if (monthlyRate === 0) {
      return monthlyAmount * months;
    }
    
    return monthlyAmount * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate);
  };

  const projectionHorizons = [
    { years: 5, isHighlighted: false },
    { years: 10, isHighlighted: false },
    { years: 20, isHighlighted: false },
    { years: 30, isHighlighted: true }
  ];

  const annualReturn = getAnnualReturn(settings?.investmentType);

  const projectionCards = projectionHorizons?.map(horizon => {
    const amount = calculateFutureValue(monthlySpending, horizon?.years, annualReturn);
    const totalInvested = monthlySpending * 12 * horizon?.years;
    const growthPercentage = ((amount - totalInvested) / totalInvested) * 100;
    
    return {
      ...horizon,
      amount,
      growthPercentage
    };
  });

  const generateChartData = () => {
    const data = [];
    for (let year = 0; year <= 30; year++) {
      const wealthLost = calculateFutureValue(monthlySpending, year, annualReturn);
      const totalInvested = monthlySpending * 12 * year;
      data?.push({
        year,
        wealthLost: Math.round(wealthLost),
        totalInvested: Math.round(totalInvested),
        monthlySpending
      });
    }
    return data;
  };

  const chartData = generateChartData();

  const milestones = [
    {
      icon: 'Wallet',
      title: 'Emergency Fund',
      amount: 10000,
      description: 'Build a safety net covering 3-6 months of expenses for unexpected situations',
      isAchievable: true
    },
    {
      icon: 'Car',
      title: 'Vehicle Purchase',
      amount: 25000,
      description: 'Save enough for a reliable vehicle without taking on high-interest debt',
      isAchievable: true
    },
    {
      icon: 'Home',
      title: 'Down Payment',
      amount: 50000,
      description: 'Accumulate funds for a substantial down payment on your first home',
      isAchievable: true
    },
    {
      icon: 'GraduationCap',
      title: 'Education Fund',
      amount: 75000,
      description: 'Invest in education or skill development for career advancement',
      isAchievable: true
    },
    {
      icon: 'TrendingUp',
      title: 'Investment Portfolio',
      amount: 100000,
      description: 'Build a diversified investment portfolio for long-term wealth growth',
      isAchievable: true
    },
    {
      icon: 'Palmtree',
      title: 'Early Retirement',
      amount: 250000,
      description: 'Accelerate your path to financial independence and early retirement',
      isAchievable: false
    }
  ];

  const calculateYearsToAchieve = (targetAmount) => {
    let years = 0;
    let accumulated = 0;
    const monthlyRate = annualReturn / 12 / 100;
    
    while (accumulated < targetAmount && years < 50) {
      years++;
      accumulated = calculateFutureValue(monthlySpending, years, annualReturn);
    }
    
    return years;
  };

  const milestonesWithYears = milestones?.map(milestone => ({
    ...milestone,
    yearsToAchieve: calculateYearsToAchieve(milestone?.amount),
    isAchievable: calculateYearsToAchieve(milestone?.amount) <= 30
  }));

  const handleBackToDashboard = () => {
    navigate('/main-dashboard');
  };

  const handleExploreDreamSwap = () => {
    navigate('/dream-swap-calculator');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="main-content">
        <div className="content-container">
          <Breadcrumbs />

          <div className="space-y-6 md:space-y-8 animate-in">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              <div className="space-y-2">
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">
                  Wealth Projection Details
                </h1>
                <p className="text-base md:text-lg text-muted-foreground max-w-3xl">
                  Explore how your recurring expenses impact your long-term wealth across multiple time horizons
                </p>
              </div>
              <Button
                variant="outline"
                iconName="ArrowLeft"
                iconPosition="left"
                onClick={handleBackToDashboard}
                className="w-full lg:w-auto"
              >
                Back to Dashboard
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 stagger-1">
              {projectionCards?.map((card, index) => (
                <ProjectionCard
                  key={index}
                  years={card?.years}
                  amount={card?.amount}
                  growthPercentage={card?.growthPercentage}
                  isHighlighted={card?.isHighlighted}
                />
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 stagger-2">
              <div className="lg:col-span-2">
                <GrowthChart 
                  projectionData={chartData}
                  investmentType={settings?.investmentType}
                />
              </div>
              <div>
                <AssumptionsPanel settings={settings} />
              </div>
            </div>

            <div className="space-y-4 md:space-y-6 stagger-3">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-2 md:space-y-0">
                <div>
                  <h2 className="text-2xl md:text-3xl font-semibold text-foreground">
                    Investment Milestones
                  </h2>
                  <p className="text-sm md:text-base text-muted-foreground mt-1">
                    Realistic wealth-building targets based on your current spending
                  </p>
                </div>
                <div className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-muted">
                  <Icon name="Target" size={16} color="var(--color-primary)" />
                  <span className="text-xs md:text-sm text-muted-foreground caption">
                    Monthly: ${monthlySpending?.toFixed(0)}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                {milestonesWithYears?.map((milestone, index) => (
                  <MilestoneCard
                    key={index}
                    icon={milestone?.icon}
                    title={milestone?.title}
                    amount={milestone?.amount}
                    description={milestone?.description}
                    yearsToAchieve={milestone?.yearsToAchieve}
                    isAchievable={milestone?.isAchievable}
                  />
                ))}
              </div>
            </div>

            <div className="card bg-primary/5 border-primary/20">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <div className="space-y-2">
                  <h3 className="text-xl md:text-2xl font-semibold text-foreground">
                    Ready to Take Action?
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground max-w-2xl">
                    Use the Dream Swap calculator to see how cutting specific expenses can help you reach your financial goals faster
                  </p>
                </div>
                <Button
                  variant="default"
                  iconName="Repeat"
                  iconPosition="right"
                  onClick={handleExploreDreamSwap}
                  className="w-full lg:w-auto"
                >
                  Explore Dream Swap
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default WealthProjectionDetails;