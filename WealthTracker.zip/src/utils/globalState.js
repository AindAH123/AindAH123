const STORAGE_KEYS = {
  EXPENSES: 'wealth_tracker_expenses',
  SETTINGS: 'wealth_tracker_settings',
  SPENDING_LIMITS: 'wealth_tracker_spending_limits',
  THEME: 'wealth_tracker_theme'
};

const DEFAULT_SETTINGS = {
  investmentType: 'moderate',
  annualReturn: 7,
  inflationRate: 3,
  inflationEnabled: false
};

export const getExpenses = () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS?.EXPENSES);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading expenses:', error);
    return [];
  }
};

export const saveExpenses = (expenses) => {
  try {
    localStorage.setItem(STORAGE_KEYS?.EXPENSES, JSON.stringify(expenses));
    window.dispatchEvent(new CustomEvent('expensesUpdated', { detail: expenses }));
  } catch (error) {
    console.error('Error saving expenses:', error);
  }
};

export const getSettings = () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS?.SETTINGS);
    return stored ? JSON.parse(stored) : DEFAULT_SETTINGS;
  } catch (error) {
    console.error('Error loading settings:', error);
    return DEFAULT_SETTINGS;
  }
};

export const saveSettings = (settings) => {
  try {
    localStorage.setItem(STORAGE_KEYS?.SETTINGS, JSON.stringify(settings));
    window.dispatchEvent(new CustomEvent('settingsUpdated', { detail: settings }));
  } catch (error) {
    console.error('Error saving settings:', error);
  }
};

export const getSpendingLimits = () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS?.SPENDING_LIMITS);
    return stored ? JSON.parse(stored) : {};
  } catch (error) {
    console.error('Error loading spending limits:', error);
    return {};
  }
};

export const saveSpendingLimits = (limits) => {
  try {
    localStorage.setItem(STORAGE_KEYS?.SPENDING_LIMITS, JSON.stringify(limits));
  } catch (error) {
    console.error('Error saving spending limits:', error);
  }
};

export const getTheme = () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS?.THEME);
    return stored || 'light';
  } catch (error) {
    console.error('Error loading theme:', error);
    return 'light';
  }
};

export const saveTheme = (theme) => {
  try {
    localStorage.setItem(STORAGE_KEYS?.THEME, theme);
    // Apply dark class for Tailwind dark mode
    if (theme === 'dark') {
      document.documentElement?.classList?.add('dark');
    } else {
      document.documentElement?.classList?.remove('dark');
    }
    window.dispatchEvent(new CustomEvent('themeUpdated', { detail: theme }));
  } catch (error) {
    console.error('Error saving theme:', error);
  }
};

export default {
  getExpenses,
  saveExpenses,
  getSettings,
  saveSettings,
  getSpendingLimits,
  saveSpendingLimits,
  getTheme,
  saveTheme
};